/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

import javax.swing.JFrame;


/**
 *
 * @author caith_sit_brothers
 */
public class BookReader {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        readerGUI reader = new readerGUI();
        
        reader.setLocation(130,100);
        reader.setSize(800, 800);
    	reader.setVisible( true );
    	reader.setResizable(false); 
        reader.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
