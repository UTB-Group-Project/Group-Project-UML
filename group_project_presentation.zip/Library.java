/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Andrew
 */
public class Library {
    
    private ArrayList<Book> library;
    //attributes should match the number of attributes for a Book
    private int attributes;
    int size;
            
    //Creates an ArrayList with entries of type Book
    public Library()
    {
        library = new ArrayList<>();
        attributes = 6;
        
    }
    
    //Searches through an "active books" folder for files with a certain suffix (here set to .ubr for the moment)
    //Eventually, it will take all files found in this directory that are properly formatted and make a Book with the data (Title, author, genre, website, icon)
    //NEED: I need stubs for the Book methods so I can implement this.
    public void initialize()
    {
        File parent = new File("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files");
        //You can check that the File is a directory with...
        
        if (parent.isDirectory()) {
    // Take action of the directory
            }

        //You can list the contents of the directory by...

 //       File[] children = parent.listFiles();
        // This will return null if the path does not exist it is not a directory...
        //You can filter the list in a similar way...
        
        //I changed this from ".ubr"  
        //I may need to change it back later.
        File[] children = parent.listFiles(new FileFilter() {
            public boolean accept(File file) {
                return file.isDirectory() || file.getName().toLowerCase().endsWith(".txt");
            }
        });
// This will return all the files that are directories or whose file name ends
// with ".dat" (*.dat)
        
        
        //Then go through one at a time, adding each as a book to the library.
        for(int i=0; i<children.length; i++)
        {
            System.out.println(children[i].toString());
            read(children[i]);
            
            //read children[i] in using a file reader (that needs to be cleaned each time?)
            //Then create a new book with the first 5 lines
            //Then add the new book to the library
        }
    }
    
    //AND...it suddenly works.  Un-be-freakin-lievable NetBeans.
    public Book getBook(String title)
    {
        for(int i=0; i<library.size(); i++)
        {
            if(library.get(i).getTitle() == null ? title == null : library.get(i).getTitle().equals(title))
                {
                    return library.get(i);
                }
        }
        
        //THIS IS SO NOT OKAY, FIX THIS!!!
        //SOME WAY TO MAKE AN ERROR MESSAGE
        return library.get(0);
    }    //AND...it suddenly works.  Un-be-freakin-lievable NetBeans.
    
    
    public Book getBook(int entry)
    {
        return library.get(entry);
    }
        
    
    //Adds a single book to the library. 
    public boolean addBook(Book b)
    {
        //return true if successful
        library.add(b);
        size = library.size();
        return true;
    }
    
    //Adds a single book to the library.
    //IS THERE ANY REASON FOR THE BOOL RETURN VALUE????
    public boolean addBook(String title, String author, String genre, String website, String iconReference, String textAddress, int chapters)
    {
        Book b =  new Book(title, author, genre, website, iconReference, textAddress, chapters);
        library.add(b);
        size = library.size();
        return true;
    }
 
    //Adds a single book to the library.
    //IS THERE ANY REASON FOR THE BOOL RETURN VALUE????
    public boolean addBook(String[] a)
    {
        String title = a[0];
        String author = a[1];
        String genre = a[2];
        String website = a[3];
        String iconReference = a[4];
//        String textAddress = a[5];
        int chapters = new Integer(a[5]);
        Book b =  new Book(title, author, genre, website, iconReference, textAddress, chapters);
        library.add(b);
        size = library.size();
        return true;
    }
    
    //removes a single book from the library
    public boolean removeBook(String title)
    {
      //  System.out.println("**************");
         
        for(int i = 0; i < library.size(); i++)
        {
            if(library.get(i).getTitle().equals(title))
            {
              //  System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
                File afile = library.get(i).getFileName();
               // System.out.println(afile.getName());
                String absolutePath = afile.getAbsolutePath();
               // System.out.println(absolutePath);
                String filePath = absolutePath.substring(0,absolutePath.lastIndexOf(File.separator));
               // System.out.println(filePath);
                filePath = filePath.substring(0,filePath.lastIndexOf("\\"));
               // System.out.println(filePath);
                String destination = filePath + "\\Group Project Deleted Files\\" + afile.getName();
               // System.out.println(destination);
                if(afile.renameTo(new File(destination)))
                {
                    System.out.println("File move successful!");
                    library.remove(i);
                    return true;
                }
                else
                {
                    System.out.println("File failed to move!");
                    return false;
                }

            }
        }
        
        size = library.size();
                        
        return false;
    }
    
    //**OPTIONAL**
    //Undoes a recent removeBook
    public boolean recover(Book b)
    {
        //return true if successful
        return true;
    }
    
    public int getSize()
    {
        return size;
    }
    
    //Implements the Book search method on all books to find all instances of a search string
    public boolean[] searchAll(String searchString)
    {
        boolean[] results = new boolean[library.size()];
        
        for(int i=0; i<library.size(); i++)
        {
            results[i] = library.get(i).search(searchString);
        }
        
        return results;
    }
    
    /*
     * This one needs some serious work, but this would return the text of a given 
    chapter which was passed according to its reference (probably book-chapter)
    * WHY WOULD I NEED THIS HERE, NOT IN THE BOOK???
    */
    public String getAChapter(String title, int chapter)
    {
        
        for(int i = 0; i < library.size(); i++)
        {
            if(library.get(i).getTitle().contains(title))
            {
                return library.get(i).getChapter(chapter);
            }
        }
        
        return "Selected book or chapter not found.";
    }
    
    
    public String getAChapter(int entry, int chapter)
    {
        
        try{
            return library.get(entry).getChapter(chapter);
        }
        catch(Exception e)
        {
            return "Selected book or chapter not found.";
        }
    }
    
    /*
     * This one needs some serious work, but this would return the text of a given 
    book which was passed according to its reference (probably book-chapter)
    * 
    * I am not sure that both this and the chapter one are needed.  Likely we can
    * pick to return a chapter at a time OR a book at a time and get rid of the other.
    * 
    * DO I NEED THIS AT ALL FOR ANY REASON????????????????
    */
 /*   public String getBook(String reference)
    {
        return "This will return a selected book";
    }
   */ 
    
    //saves all highlighted portions of text
    public void saveHighlights()
    {
        
        File dir = library.get(0).getFileName();
        String absPath = dir.getAbsolutePath();
        String path = absPath.substring(0,absPath.lastIndexOf(File.separator));
        
        try{
            
            PrintWriter fout = new PrintWriter(new BufferedWriter(new FileWriter(path + "\\highlighted.txt")));        
            
        ArrayList results = new ArrayList();
        
        //fout = all the stuff needed to print this to a file.
        
        String temp = "";
        //this loops through all books and puts the highlighted text into a file
        for(int i=0; i<library.size(); i++)
        {
            results.add(library.get(i).getHighlighted());
            if(!results.isEmpty())
            {
                for(int j = 0; j<results.size(); j++)
                {
                    temp = results.get(j).toString();
                    fout.println(temp);
                    temp = "";
                }
                if(!results.isEmpty())
                {
                    fout.println("From " + library.get(i).getTitle() + ", by " + library.get(i).getAuthor());
                }
                
                results.removeAll(results);
            }//put back in library?
        }
        
                fout.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        //this will need a try/catch/throw
        

    }
    
    
    //change these to a mapping of title-0, author-1 ??
    public void sortBy(String field)
    {
        
        if(field.equalsIgnoreCase("genre"))
        {
            Collections.sort(library, new genreComparator());
        }
        else if(field.equalsIgnoreCase("author"))
        {
            Collections.sort(library, new authorComparator());
        }
        else
        {
            Collections.sort(library, new titleComparator());
        }

    }
    
    public String getText(String title)
    {
        
        for(int i = 0; i < library.size(); i++)
        {
            if(library.get(i).getTitle().contains(title))
            {
                return library.get(i).getText();
            }
        }
        
        return "Selected book or chapter not found.";
    }
    
    
    public boolean importFile(File fileName)
    {
        
        String name = fileName.getName();
        String absPath = library.get(0).getFileName().getAbsolutePath();
        String path = absPath.substring(0,absPath.lastIndexOf(File.separator));
        String dest = path + "\\" + name;
        System.out.println(dest);

                if(fileName.renameTo(new File(dest)))
                {
                    System.out.println("File move successful!");
                    read(new File(dest));
                    return true;
                }
                else
                {
                    System.out.println("File failed to move!");
                    return false;
                }
                

    }
    
    
    public void read(File fileName)
    {
        int chapters = 0;
        
        try{
        BufferedReader in = new BufferedReader(new FileReader(fileName));         
        String inLine[] = new String[attributes];
        String line;
        String stringIn = "";
        for(int i = 0; i < attributes - 1; i++)
        {
            inLine[i] = in.readLine(); 
        }
        
        Book b = new Book();

        b.setFileName(fileName);
            
        
        while((line = in.readLine()) != null)
        {
            
            //writing chapters doesn't work right now
            b.addText(line);
            
            if(line.contains("#"))
            {
                chapters+=1;
            }
       /*     if (line.contains("#"))
            {
                System.out.println("New Chapter");
                b.addText(stringIn);
                System.out.println(stringIn);
                stringIn = "";
            }
            else
            {
                stringIn = stringIn + " " + line;
            }*/
//            System.out.println(line);
//            if(line.indexOf('#') != -1)
//            {
//                System.out.println("New Chapter Beginning");
//                b.addText(stringIn);
//                stringIn = "";
//            }
//            else
//            {
//                stringIn = stringIn + " " + line;
//                System.out.println(stringIn);                
//            }
            
            
        }
        System.out.println("here");
      //  b.addText(stringIn);
        
        inLine[attributes-1] = chapters + "";
        
        b.updateAll(inLine);
        library.add(b);
        System.out.println("Book successfully read in");
        System.out.println(" ");
        in.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
        System.out.println("Size of library is: " + library.size());
        size = library.size();

        //System.out.println(data.length);
    }
    
    public void display()
    {
        for (int i = 0; i < library.size(); i++)
        {
            System.out.println(library.get(i).getTitle());
        }
    }
   



 private class authorComparator implements Comparator<Book>{
   @Override
   public int compare(Book book1, Book book2) {
    return (book1.getAuthor().compareTo(book2.getAuthor()));
   }
 }
 
  private class genreComparator implements Comparator<Book>{
   @Override
   public int compare(Book book1, Book book2) {
    return (book1.getGenre().compareTo(book2.getGenre()));
   }
 }
  
   private class titleComparator implements Comparator<Book>{
   @Override
   public int compare(Book book1, Book book2) {
    return (book1.getTitle().compareTo(book2.getTitle()));
   }
 }








}
