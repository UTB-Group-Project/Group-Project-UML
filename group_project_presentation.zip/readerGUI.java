/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

//import static groupproject1.SearchExample.ERROR_COLOR;
//import static groupproject1.SearchExample.HILIT_COLOR;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.awt.Color;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.View;

//import java.lang.Process;


/**
 *
 * @author caith_sit_brothers
 */
class readerGUI extends JFrame 
{
    JMenuBar menuBar; 
    JMenu menu1, menu2, menu3, menu4, menu5, menu6, searchAllMenu;
    JMenuItem menuItem, menuItem1, menuItem2, menuItem3, menuItem4, menuItem5, menuItem6;
    JMenuItem menuItem7, menuItem8, menuItem9, menuItem10, menuItem11, menuItem12;
    JMenuItem menuItem13, menuItem14, menuItem15, menuItem16, menuItem17, menuItem18;
    JMenuItem menuItem19, searchAllItem;
    
    ImageIcon logo;
    JLabel loguin1, loguin2, title;
    JTextArea readerArea;
    JPanel rightSide, leftSide, bottomSide, bottomIcon;
    String text;
    JButton importBook, deleteBook, listBook, saveButton;
    JTextField searchField;
    JScrollPane scroll;
    DefaultComboBoxModel model;
    
    //BufferedReader in;
    
    JComboBox comboBox;
    
    private static Library library;
    private ArrayList<String> titles;
    private String currentBook;
    
    
    
    final static Color  HILIT_COLOR = Color.LIGHT_GRAY;
    final static Color  ERROR_COLOR = Color.PINK;
    final static String CANCEL_ACTION = "cancel-search";
    
    final Color entryBg;
    final Highlighter hilit;
    final Highlighter.HighlightPainter painter;
    
    readerGUI()
    { 
        //*********************************************
        //THERE IS A WHAT!!!?!?!?!?!!
        //import javax.swing.text.Highlighter;
        //*********************************************
        //Highlighter g;
        
        //*********************************************
        //*********************************************
        
        
        
        super("Book Reader");    	
    	String cad = "logo.png";
        //setBackground(Color.blue);
        setLayout(new FlowLayout());

        
        hilit = new DefaultHighlighter();
        painter = new DefaultHighlighter.DefaultHighlightPainter(HILIT_COLOR);

    	
        library = new Library();
        library.initialize();
        library.display();
    	
        menuBar = new JMenuBar(); 

    	menu1 = new JMenu("Book Reader");  //TOP MENU
        menuItem19 = new JMenuItem("Print Book");
        menuItem = new JMenuItem("Exit");         
        
        menu2 = new JMenu("Font");
        menuItem1 = new JMenuItem("Arial");
        menuItem2 = new JMenuItem("Verdana"); 
        
        menu3 = new JMenu("Font Color");
        menuItem3 = new JMenuItem("Black");
        menuItem4 = new JMenuItem("Blue"); 
        menuItem5 = new JMenuItem("White");
        menuItem6 = new JMenuItem("Red");
        
        menu4 = new JMenu("Background Color");
        menuItem7 = new JMenuItem("Black");
        menuItem8 = new JMenuItem("Blue");
        menuItem9 = new JMenuItem("White"); 
        menuItem10 = new JMenuItem("Red");
        
        menu5 = new JMenu("Tools");
        menuItem11 = new JMenuItem("Dictionary");
        menuItem12 = new JMenuItem("Website"); 
        menuItem16 = new JMenuItem("Font +");
        menuItem17 = new JMenuItem("Font -");
        menuItem18 = new JMenuItem("Print Quotes");
        
        menu6 = new JMenu("Sort");
        menuItem13 = new JMenuItem("Sort by Title");
        menuItem14 = new JMenuItem("Sort by Author"); 
        menuItem15 = new JMenuItem("Sort by Genre");  
        
        searchAllMenu = new JMenu("Search All Books");
        searchAllItem = new JMenuItem("Search All");
        
        menuBar.add(menu1);
        menuBar.add(menu2);
        menuBar.add(menu3);
        menuBar.add(menu4);
        menuBar.add(menu5);
        menuBar.add(menu6);
        menuBar.add(searchAllMenu);
        
        menu1.add(menuItem);
        menu1.add(menuItem19);
        
        menu2.add(menuItem1);
        menu2.add(menuItem2);
        
        menu3.add(menuItem3);
        menu3.add(menuItem4);
        menu3.add(menuItem5);
        menu3.add(menuItem6);
        
        menu4.add(menuItem7);
        menu4.add(menuItem8);
        menu4.add(menuItem9);
        menu4.add(menuItem10);
        
        menu5.add(menuItem11);
        menu5.add(menuItem12);
        menu5.add(menuItem16);
        menu5.add(menuItem17);
        menu5.add(menuItem18);
        add(menuBar);
        
        menu6.add(menuItem13);
        menu6.add(menuItem14);
        menu6.add(menuItem15);
        
        searchAllMenu.add(searchAllItem);
        
                
       // title = new JLabel(" *** BOOK READER *** ");
       // add(title);

        
        
        titles = new ArrayList<>();
        for(int i=0; i<library.getSize(); i++)
        {
            //titles.add(library.getBook(i).getTitle() + ", " + library.getBook(i).getAuthor());
            titles.add(library.getBook(i).getTitle());
        }
            
            
                            
        rightSide = new JPanel(); //PANEL for buttons  
                rightSide.add(new JLabel("Please select the Book to read:"));
                model = new DefaultComboBoxModel();
                for(int i=0; i<titles.size(); i++)
                {
                    model.addElement(titles.get(i));
                }
 
                comboBox = new JComboBox(model);
                rightSide.add(comboBox);
                
                searchField = new JTextField("", 10);
                rightSide.add(searchField);
                saveButton = new JButton("Save");
                rightSide.add(saveButton);
                entryBg = searchField.getBackground();
                add(rightSide);
                
                        
                leftSide = new JPanel(); //PANEL for buttons  
 
         
                readerArea = new JTextArea("", 25, 60);
                readerArea.setLineWrap(true);
                readerArea.setWrapStyleWord(true);
                readerArea.setEditable(false);
                readerArea.setHighlighter(hilit);
                
                setReaderText();
                

                leftSide.add(readerArea);
                
                add(leftSide);
                
                scroll = new JScrollPane (readerArea, 
                    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
                add(scroll);
                
                //frame.setVisible (true);
        
        bottomSide = new JPanel(); //PANEL for buttons  
                importBook = new JButton("Import New Book");
                bottomSide.add(importBook);
                deleteBook = new JButton("Delete Existing Book");
                bottomSide.add(deleteBook);
                listBook = new JButton("List all Books");
                bottomSide.add(listBook);
                add(bottomSide);
                
                
               bottomIcon = new JPanel();
               bottomIcon.setPreferredSize(new Dimension(150,150));
               logo = new ImageIcon(cad);//create icon
               loguin1 = new JLabel(logo);//create label
               //loguin1.setBounds(150,30,100,100);//where?
               loguin1.setMaximumSize(new Dimension(50,50));
               bottomIcon.add(loguin1); //add
               
               add(bottomIcon);
                
                
        ActionEventHandler manejador = new ActionEventHandler();

	menuItem.addActionListener(manejador);
        menuItem1.addActionListener(manejador);
        menuItem2.addActionListener(manejador);
        menuItem3.addActionListener(manejador);
        menuItem4.addActionListener(manejador);
        menuItem5.addActionListener(manejador);
        menuItem6.addActionListener(manejador);
        menuItem7.addActionListener(manejador);
        menuItem8.addActionListener(manejador);
        menuItem9.addActionListener(manejador);
        menuItem10.addActionListener(manejador);
        menuItem11.addActionListener(manejador);
        menuItem12.addActionListener(manejador);        
        menuItem13.addActionListener(manejador);
        menuItem14.addActionListener(manejador);
        menuItem15.addActionListener(manejador);
        menuItem16.addActionListener(manejador);
        menuItem17.addActionListener(manejador);
        menuItem18.addActionListener(manejador);
        menuItem19.addActionListener(manejador);
        searchAllItem.addActionListener(manejador);
        
        importBook.addActionListener(manejador);
        deleteBook.addActionListener(manejador);
        listBook.addActionListener(manejador);
        
        saveButton.addActionListener(manejador);
     //   searchField.addActionListener(new textListener());
        searchField.getDocument().addDocumentListener(new textListener());
        
        comboBox.addActionListener(manejador);
        
        
//        readerArea.addMouseListener(new MouseAdapter() {
//        @Override
//        public void mousePressed(MouseEvent e) {
//            JTextArea text = (JTextArea) e.getSource();
//            text.selectAll();
//            System.out.println(text);
//        }      
//    });
      //  addFocusListener(new myFocusListener());
  
    }
    
    
    
    
    
    
    
    public void search() {
        
//        try {
//            BufferedReader in = new BufferedReader(new StringReader(library.getBook(currentBook).getText()));
//            readerArea.read(in, null);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        
//           BufferedReader in = new BufferedReader(new StringReader(library.getBook(currentBook).getText()));        

        
        

        
//        InputMap im = entry.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
//        ActionMap am = entry.getActionMap();
//        im.put(KeyStroke.getKeyStroke("ESCAPE"), CANCEL_ACTION);
//        am.put(CANCEL_ACTION, new SearchExample.CancelAction());
            
            
        hilit.removeAllHighlights();
        
        String s = searchField.getText();
        System.out.println(s);
        if (s.length() <= 0) {
            System.out.println("Nothing to search");
            return;
        }
        
        //String content = library.getBook(currentBook).getText();
        String content  = readerArea.getText();
        int index = content.indexOf(s, 0);
        while (index >= 0) {
            if(index>=0)// match found
            {
            try {
                int end = index + s.length();
                hilit.addHighlight(index, end, painter);
                readerArea.setCaretPosition(end);
                
                index = content.indexOf(s,index+1);
                
              //  System.out.println("'" + s + "' found. Press ESC to end search");
            } catch (BadLocationException err) {
                err.printStackTrace();
            }
        } 
            else {
            searchField.setBackground(ERROR_COLOR);
            System.out.println("'" + s + "' not found. Press ESC to start a new search");
            }
        }

    }
    
    

    

//    void message(String msg) {
//        status.setText(msg);
//    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
          
                
                
//    private class myFocusListener implements FocusListener{
//
//   
//    public void focusGained(FocusEvent e) {
//        dumpInfo(e);
//    }
//
//    
//    public void focusLost(FocusEvent e) {
//        //dumpInfo(e);
//    }
//
//    private void dumpInfo(FocusEvent e) {
//        //System.out.println("Source  : " + name(e.getComponent()));
//        //System.out.println("Opposite : " + name(e.getOppositeComponent()));
//        //System.out.println("Temporary: " + e.isTemporary());
//
//        Component c = e.getComponent();
//        System.out.println(c.toString());
//        if (c instanceof JFormattedTextField) {
//            ((JFormattedTextField) c).requestFocus();
//            ((JFormattedTextField) c).setText(((JFormattedTextField) c).getText());
//            ((JFormattedTextField) c).selectAll();
//        } else if (c instanceof JTextField) {
//            ((JTextField) c).requestFocus();
//            ((JTextField) c).setText(((JTextField) c).getText());
//            ((JTextField) c).selectAll();
//        }
//    }
//
//    private String name(Component c) {
//        return (c == null) ? null : c.getName();
//    }
//}
                
                
                
                
          
    
    
    
    private class textListener implements DocumentListener
    {
    public void insertUpdate(DocumentEvent ev) {
       search();
    }
    
    public void removeUpdate(DocumentEvent ev) {
        search();
    }
    
    public void changedUpdate(DocumentEvent ev) {
    }
    
//    class CancelAction extends AbstractAction {
//        public void actionPerformed(ActionEvent ev) {
//            hilit.removeAllHighlights();
//            searchField.setText("");
//            searchField.setBackground(entryBg);
//        }
//    }
    }
    
      private class ActionEventHandler implements ActionListener
	{
                @Override
		public void actionPerformed( ActionEvent evento)
		{
		
			if (evento.getSource() == menuItem)
				System.exit(0);
                        
                        if (evento.getSource() == menuItem1)
                        {
                                Font font = new Font("Arial", Font.BOLD, 12);
                                readerArea.setFont(font);
                        }
                        
                        if (evento.getSource() == menuItem2)
                        {
                                Font font = new Font("Verdana", Font.ITALIC, 12);
                                readerArea.setFont(font);
                        }
                         
                        if (evento.getSource() == menuItem3)
                        {
                                readerArea.setForeground(Color.BLACK);
                        }
                        
                        if (evento.getSource() == menuItem4)
                        {
                                readerArea.setForeground(Color.BLUE);
                        }
                        
                        if (evento.getSource() == menuItem5)
                        {
                                readerArea.setForeground(Color.WHITE);
                        }
                        
                        if (evento.getSource() == menuItem6)
                        {
                                readerArea.setForeground(Color.RED);
                        }
                        
                        if (evento.getSource() == menuItem7)
                        {                               
				readerArea.setBackground(Color.BLACK);
                        }
                        
                        if (evento.getSource() == menuItem8)
                        {                               
				readerArea.setBackground(Color.BLUE);
                        }
                        
                        if (evento.getSource() == menuItem9)
                        {                               
				readerArea.setBackground(Color.WHITE);
                        }
                        
                        if (evento.getSource() == menuItem10)
                        {                               
				readerArea.setBackground(Color.RED);
                        } 
                        
                        if (evento.getSource() == menuItem11)
                        {
                            try{
				Desktop.getDesktop().browse(new URI("http://dictionary.reference.com/browse/"));
                            }
                            catch (URISyntaxException | IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        
                        if (evento.getSource() == menuItem12)
                        {
                            try{
				Desktop.getDesktop().browse(new URI(library.getBook(currentBook).getWebsite()));
                            }
                            catch(IOException | URISyntaxException e)
                            {
                                e.printStackTrace();
                            }
                        }        
                        
                        if (evento.getSource() == menuItem13)
                        {
                            library.sortBy("title");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                //titles.add(library.getBook(i).getTitle() + ", " + library.getBook(i).getAuthor());
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }    
                        
                        if (evento.getSource() == menuItem14)
                        {
                            library.sortBy("author");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                //titles.add(library.getBook(i).getTitle() + ", " + library.getBook(i).getAuthor());
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }            
                        
                        if (evento.getSource() == menuItem15)
                        {
                            library.sortBy("genre");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                //titles.add(library.getBook(i).getTitle() + ", " + library.getBook(i).getAuthor());
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }
                        
                                                
                        
                        if (evento.getSource() == menuItem16)
                        {
                            Font font = new Font(readerArea.getFont().getName(), readerArea.getFont().getStyle(), readerArea.getFont().getSize() + 2);                            readerArea.setFont(font);
                            readerArea.setFont(font);
                            
                        }                                                  
                        
                        if (evento.getSource() == menuItem17)
                        {
                            //This does not prevent a user from driving the font size negative
                            Font font = new Font(readerArea.getFont().getName(), readerArea.getFont().getStyle(), readerArea.getFont().getSize() - 2);                            readerArea.setFont(font);
                            readerArea.setFont(font);
                        }                          
                        
                        if (evento.getSource() == menuItem18)
                        {
                            library.saveHighlights();
                        }  
                        
                        
                                               
                        if (evento.getSource() == menuItem19)
                        {
                         
                            PrinterJob job = PrinterJob.getPrinterJob();
                            job.setPrintable(new BookPrinter());
                            
                            if(job.printDialog())
                            {
                                try {
                                    readerArea.print();
                                    //job.print();
                                }
                                catch (PrinterException e) {     }
                            }
                        }       
                        
                        
                        if (evento.getSource() == searchAllItem)
                        {
                            String query = JOptionPane.showInputDialog(null, 
                                    "Input whole library search query", "Type Query", JOptionPane.INFORMATION_MESSAGE);           
                            //System.out.println(query);
                            boolean[] seeAll = new boolean[library.getSize()];
                            seeAll = library.searchAll(query);
                            String disp = "";
                            for(int i=0; i<seeAll.length; i++)
                            {
                                disp = disp + "Query in " + library.getBook(i).getTitle() + " ? " + seeAll[i] + " \n";
                            }
                            
                            //readerArea.setText(disp);
                            
                            setReaderText(disp);
                            return ;
                        }
                            
                        
                     /*   if (evento.getSource() == importBook)
                        {                  
                            File dd = new File("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files2");
                            library.read(dd.listFiles()[0]);
                            System.out.println("******************");
                            System.out.println("******************");
                            titles.add(library.getBook(library.getSize()-1).getTitle());
                            library.display();
                            
                            
                            
                            
                            
                            
                            
                model.addElement(titles.get(titles.size()-1));

                            
                            
                            
                            
                        }*/
                        
                        if ( evento.getSource() == importBook)
                        {
                            //***********************************8
                            //*************************************8
                            //CAN DO THIS WITH THE CLASS VARIABLE titles NOW
                            //*************************************
                            //****************************************
                            boolean success = false;
                            System.out.println("Import Book Options");
                           
                            
                            String path = JOptionPane.showInputDialog(null, 
                                    "Input absolute path of book to import", "Import Book", JOptionPane.INFORMATION_MESSAGE);

                            if(library.importFile(new File(path)))
                            {
                            library.getBook(library.getSize()-1).displayAll();
                            Book b = library.getBook(library.getSize() - 1);
                            titles.add(b.getTitle() + ", " + b.getAuthor());
                            model.addElement(titles.get(titles.size()-1));
                            System.out.println("Book import successful");
                            }
                            else
                            {
                                System.out.println("Attempted import unsuccessful");
                            }
                            //library.display();
                            
                            
                            
                            
                            
                            
                            //This assumes the add was successful...dangerous.

                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        if (evento.getSource() == deleteBook)
                        {     
                            //***********************************8
                            //*************************************8
                            //CAN DO THIS WITH THE CLASS VARIABLE titles NOW
                            //*************************************
                            //****************************************
                            boolean success = false;
                            System.out.println("Delete Book Options");
//                            String[] possibleValues = new String[library.getSize()];
//                            for(int i=0; i<library.getSize(); i++)
//                            {
//                                possibleValues[i] = library.getBook(i).getTitle();
//                            }
//
//                            Object selectedValue = JOptionPane.showInputDialog(null,
//                                    "Choose one", "Input",
//                                    JOptionPane.INFORMATION_MESSAGE, null,
//                                    possibleValues, possibleValues[0]);
                            
                                    Object selectedValue = JOptionPane.showInputDialog(null,
                                    "Choose a book to delete", "Input",
                                    JOptionPane.INFORMATION_MESSAGE, null,
                                    titles.toArray(), titles.get(0));
                            
                            
/*                            for (int i = 0; i<possibleValues.length; i++)
                            {
                                if(possibleValues[i].equals(selectedValue))
                                {
                                    setReaderText(library.getBook(i).getText());
                                }
                            }
                            
*/
                            //titles.remove(selectedValue.toString());
                            success = library.removeBook(selectedValue.toString());
                            System.out.println("Delete Completed?" + success);
                            if(success)
                            {
                                titles.remove(selectedValue.toString());
                                library.display();
                            }
                            else
                            {
                                System.out.println ("Delete Failure.");
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            model.removeElement(selectedValue);
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        if (evento.getSource() == listBook)
                        {                      
                            System.out.println("It's getting here");
                            String[] possibleValues = new String[library.getSize()];
                            String disp = "";
                            int end = library.getSize();
                            for(int i=0; i<end; i++)
                            {
                                //This part may or may not be necessary, but it wasn't working without it, so :-p
                                possibleValues[i] = library.getBook(i).getTitle();
                                disp = disp.concat(possibleValues[i] + "\n");
                            }

                            
                            setReaderText(disp);
//                            String[] possibleValues = { "First", "Second", "Third" };
                            
                            //I'M REALLY NOT SURE WHY IT ISN'T WORKING WITHOUT THIS STUFF.
                            //SOME TYPE OF UPDATE NEEDED PROBABLY
                            //MAKE A NEW LISTENER FOR THESE???
                            return;
                            Object selectedValue = JOptionPane.showInputDialog(null,
                                    "Choose one", "Input",
                                    JOptionPane.INFORMATION_MESSAGE, null,
                                    possibleValues, possibleValues[0]);
                            for (int i = 0; i<possibleValues.length; i++)
                            {
                                if(possibleValues[i].equals(selectedValue))
                                {
                                    setReaderText(library.getBook(i).getText());
                                }
                            }
                            System.out.println(selectedValue.toString());
                            System.out.println(selectedValue.equals("Second"));
                            return;
                            //setReaderText("Book 2\nHIIIIIII\nHOWWWWW\nAREEEEEEEEEE YOUUUUUUUUUUUU");                             
                            System.out.println("It's getting here");                                
                               /* for(int i=0; i<library.getSize(); i++)
                                {
                                    disp = disp + library.getBook(i).getTitle() + "\n";
                                }
                                */

                        }
                        
                        if ( evento.getSource() == saveButton)
                        {
                            String bonMot = "";
                            bonMot = searchField.getText();
                            System.out.println(bonMot);
                           // System.out.println(library.getBook(currentBook).search(query).get(0).toString());
                            library.getBook(currentBook).save(bonMot);
                            
                            //change this to be more like the SearchExample
                            
                            
                        }
                        
                        /*
                        if (evento.getSource() == comboBox)
                        {                               
                               
                                JOptionPane.showInputDialog("hi");
                        }*/
                        
//                        if(comboBox.getSelectedItem() == "Lorem Ipsum")
//                        {
//                            setReaderText( "\n\t\t LORE IPSUM \n\n"
//               + "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id mattis orci. \n"
//               + "Suspendisse cursus diam quis arcu fermentum dapibus. Donec lacinia, eros eget \n"
//               + "tincidunt varius, sem enim rhoncus tellus, a tempor magna magna et tortor. Integer \n"
//               + "mattis augue metus. Proin nec orci fringilla, molestie nibh rhoncus, scelerisque neque. \n"
//               + "Nunc mi lorem, ultricies sed mattis vitae, pulvinar euismod magna. Phasellus blandit \n"
//               + "diam mauris, eget ornare risus pharetra vel. Vestibulum velit nulla, varius sit amet \n"
//               + "felis vel, adipiscing dignissim nisi. Class aptent taciti sociosqu ad litora torquent \n"
//               + "per conubia nostra, per inceptos himenaeos. Vestibulum non magna quis nunc hendrerit \n"
//               + "scelerisque id vitae dolor.\n" +
//               "\n" +
//               "Donec justo ipsum, aliquet ac cursus at, consequat a mauris. In consequat vestibulum \n"
//               + "laoreet. Donec dictum mollis laoreet. Duis vel feugiat eros, at dapibus dui. Class \n"
//               + "aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. \n"
//               + "Curabitur lacus magna, lobortis eu arcu vel, interdum commodo arcu. Pellentesque \n"
//               + "ultrices pellentesque pellentesque. Proin eget malesuada velit. Proin rhoncus ante in \n"
//               + "egestas viverra. Integer gravida a elit vitae viverra. Maecenas tristique nec lacus at \n"
//               + "imperdiet. Integer nec est sit amet massa placerat cursus in eget neque. Maecenas \n"
//               + "pulvinar elit libero, nec blandit enim posuere in. Fusce aliquam nulla sed velit \n"
//               + "accumsan, id eleifend tellus viverra. Aenean vestibulum urna ut tempor pulvinar. In \n"
//               + "eleifend pretium nunc, quis dapibus libero aliquet ac.\n" +
//               "\n" +
//               "Nulla nec arcu et enim ultrices congue in at ligula. Sed bibendum, nisl non aliquam \n"
//               + "rutrum, urna sem faucibus dui, sed elementum nisi magna ultrices diam. Ut elit dolor, \n"
//               + "hendrerit varius metus et, semper sodales dui. Morbi ultrices enim id libero porttitor, \n"
//               + "sit amet auctor augue ornare. Cras placerat mollis sem id adipiscing. In dapibus eros \n"
//               + "dolor. Integer eu risus urna. Suspendisse sed eleifend justo. Integer scelerisque et \n"
//               + "arcu id porttitor. Maecenas ut ultrices purus, pulvinar hendrerit dui. Vivamus varius \n"
//               + "enim id tincidunt interdum. Mauris congue tristique velit, sit amet sodales mi. Integer \n"
//               + "tempus semper dui eu sodales. Cras feugiat eget purus nec viverra. Proin feugiat diam \n"
//               + "nec blandit aliquet.\n" +
//               "\n" +
//               "In porta non quam et vehicula. Etiam leo dui, pretium at dictum ut, cursus vel felis. \n"
//               + "Vivamus blandit posuere eros. Etiam ornare purus sit amet luctus porttitor. Nam \n"
//               + "porttitor diam est, eget accumsan enim volutpat vel. Nullam tincidunt euismod dignissim. \n"
//               + "Donec sagittis nisi ac orci gravida tempus. Praesent ac nisi a odio ultricies consectetur. Duis non interdum erat.\n" +
//               "\n" +
//               "Phasellus ullamcorper nibh libero, et molestie augue consectetur sed. Maecenas velit leo, \n"
//               + "rhoncus et dapibus sit amet, mollis sit amet sem. Fusce adipiscing dictum pellentesque. \n"
//               + "Duis iaculis felis vel sem volutpat, in mattis leo rhoncus. Vivamus sollicitudin \n"
//               + "volutpat purus, ac pulvinar dolor. Suspendisse fringilla leo ac tincidunt lacinia. \n"
//               + "Nulla vel urna in lacus tristique mattis. Aliquam eget molestie magna, in pharetra arcu. \n"
//               + "Maecenas aliquam turpis at viverra tempus. Cras laoreet, quam eu rutrum auctor, felis \n"
//               + "nunc congue eros, eu ultrices lorem lacus a nulla. Vestibulum luctus mi placerat neque \n"
//               + "commodo luctus. Fusce at nisi tristique, blandit tortor eu, imperdiet lectus. Cras sed \n"
//               + "commodo nisi. In hac habitasse platea dictumst.\n");
//          
//                        }
//                        
//                        if(comboBox.getSelectedItem() == "Book 2")
//                        {
//                               //JOptionPane.showInputDialog("Book 2");
//                            setReaderText("Book 2\nHIIIIIII\nHOWWWWW\nAREEEEEEEEEE YOUUUUUUUUUUUU");
//                        }
//                        
//                        if(comboBox.getSelectedItem() == "Book 3")
//                        {
//                             setReaderText("Book 3 THIS IS A DIFFERENT STORY\n I HOPE YOU ARE DOING GREAT");
//                        }
//                        
                        for(int i = 0; i<titles.size(); i++)
                        {
                            if(comboBox.getSelectedItem() == titles.get(i))
                            {
                                setReaderText(library.getBook(i).getText());
                                currentBook = titles.get(i);
                                ImageIcon myIcon = new ImageIcon(library.getBook(i).getIconReference());
                                Image img = myIcon.getImage();
                                Image newimg = img.getScaledInstance(150, 150,  java.awt.Image.SCALE_SMOOTH);
                                ImageIcon newIcon = new ImageIcon(newimg);
                                loguin1.setIcon(newIcon);
                                System.out.println(library.getBook(i).getIconReference());
                                bottomIcon.add(loguin1);
                                //System.out.println(scroll.getViewport().getViewPosition());
                                scroll.getViewport().setViewPosition(new Point(10,10000));
                                System.out.println(scroll.getViewport().getViewPosition());                                
                            }
                        }
                        
                }
        }
      
      
      public void setReaderText()
      {
          String text1;
        
          text1 = "Welcome to the Universal Book Reader.  \n \n Please make yourself at home. \n \n \n \n"
                  + "At the Universal Book Reader, your reading experience is our FIRST priority.";
          
          readerArea.setBackground(Color.WHITE);
          readerArea.setForeground(Color.BLACK);
          
          readerArea.setText(text1);
      }
      
      public void setReaderText(String text)
      {   
          readerArea.setText(text);
      }
}
