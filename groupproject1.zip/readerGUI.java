/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

//import java.lang.Process;


/**
 *
 * @author caith_sit_brothers
 */
class readerGUI extends JFrame 
{
    JMenuBar menuBar; 
    JMenu menu1, menu2, menu3, menu4, menu5, menu6;
    JMenuItem menuItem, menuItem1, menuItem2, menuItem3, menuItem4, menuItem5, menuItem6;
    JMenuItem menuItem7, menuItem8, menuItem9, menuItem10, menuItem11, menuItem12;
    JMenuItem menuItem13, menuItem14, menuItem15;
    
    ImageIcon logo;
    JLabel loguin1, loguin2, title;
    JTextArea readerArea;
    JPanel rightSide, leftSide, bottomSide;
    String text;
    JButton importBook, deleteBook, listBook, searchBook;
    JTextField searchField;
    DefaultComboBoxModel model;
    
    JComboBox comboBox;
    
    private static Library library;
    private ArrayList<String> titles;
    private String currentBook;
    
    readerGUI()
    { 
        //*********************************************
        //THERE IS A WHAT!!!?!?!?!?!!
        //import javax.swing.text.Highlighter;
        //*********************************************
        //Highlighter g;
        
        //*********************************************
        //*********************************************
        
        
        
        super("Book Reader");    	
    	String cad = "logo.png";
        //setBackground(Color.blue);
        setLayout(new FlowLayout());
    	
        library = new Library();
        library.initialize();
        library.display();
    	
        menuBar = new JMenuBar(); 

    	menu1 = new JMenu("Book Reader");  //TOP MENU
        menuItem = new JMenuItem("Exit"); 
        
        menu2 = new JMenu("Font");
        menuItem1 = new JMenuItem("Arial");
        menuItem2 = new JMenuItem("Verdana"); 
        
        menu3 = new JMenu("Font Color");
        menuItem3 = new JMenuItem("Black");
        menuItem4 = new JMenuItem("Blue"); 
        menuItem5 = new JMenuItem("White");
        menuItem6 = new JMenuItem("Red");
        
        menu4 = new JMenu("Background Color");
        menuItem7 = new JMenuItem("Black");
        menuItem8 = new JMenuItem("Blue");
        menuItem9 = new JMenuItem("White"); 
        menuItem10 = new JMenuItem("Red");
        
        menu5 = new JMenu("Tools");
        menuItem11 = new JMenuItem("Dictionary");
        menuItem12 = new JMenuItem("Website"); 
        
        menu6 = new JMenu("Sort");
        menuItem13 = new JMenuItem("Sort by Title");
        menuItem14 = new JMenuItem("Sort by Author"); 
        menuItem15 = new JMenuItem("Sort by Genre");         
        
        menuBar.add(menu1);
        menuBar.add(menu2);
        menuBar.add(menu3);
        menuBar.add(menu4);
        menuBar.add(menu5);
        menuBar.add(menu6);
        
        menu1.add(menuItem);
        menu2.add(menuItem1);
        menu2.add(menuItem2);
        
        menu3.add(menuItem3);
        menu3.add(menuItem4);
        menu3.add(menuItem5);
        menu3.add(menuItem6);
        
        menu4.add(menuItem7);
        menu4.add(menuItem8);
        menu4.add(menuItem9);
        menu4.add(menuItem10);
        
        menu5.add(menuItem11);
        menu5.add(menuItem12);
        add(menuBar);
        
        menu6.add(menuItem13);
        menu6.add(menuItem14);
        menu6.add(menuItem15);
        
                
        title = new JLabel(" *** BOOK READER *** ");
        add(title);
                                

        logo = new ImageIcon(cad);//create icon
    	loguin1 = new JLabel(logo);//create label
	//loguin.setBounds(150,30,100,100);//where?
	add(loguin1); //add

        
        titles = new ArrayList<>();
        for(int i=0; i<library.getSize(); i++)
        {
            titles.add(library.getBook(i).getTitle());
        }
            
            
                            
        rightSide = new JPanel(); //PANEL for buttons  
                rightSide.add(new JLabel("Please select the Book to read:"));
                model = new DefaultComboBoxModel();
                for(int i=0; i<titles.size(); i++)
                {
                    model.addElement(titles.get(i));
                }
                model.addElement("Lorem Ipsum");
                model.addElement("Book 2");
                model.addElement("Book 3");
 
                comboBox = new JComboBox(model);
                rightSide.add(comboBox);
                
                searchField = new JTextField("", 10);
                rightSide.add(searchField);
                searchBook = new JButton("Search Word");
                rightSide.add(searchBook);
                add(rightSide);
                
                        
                leftSide = new JPanel(); //PANEL for buttons  
 
         
                readerArea = new JTextArea("", 25, 60);
                readerArea.setLineWrap(true);
                readerArea.setWrapStyleWord(true);
                readerArea.setEditable(false);
                
                setReaderText();
                leftSide.add(readerArea);
                
                add(leftSide);
                
         
                JScrollPane scroll = new JScrollPane (readerArea, 
                    JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

                add(scroll);
                //frame.setVisible (true);
        
        bottomSide = new JPanel(); //PANEL for buttons  
                importBook = new JButton("Import New Book");
                bottomSide.add(importBook);
                deleteBook = new JButton("Delete Existing Book");
                bottomSide.add(deleteBook);
                listBook = new JButton("List all Books");
                bottomSide.add(listBook);
                add(bottomSide);
                
                
        ActionEventHandler manejador = new ActionEventHandler();

	menuItem.addActionListener(manejador);
        menuItem1.addActionListener(manejador);
        menuItem2.addActionListener(manejador);
        menuItem3.addActionListener(manejador);
        menuItem4.addActionListener(manejador);
        menuItem5.addActionListener(manejador);
        menuItem6.addActionListener(manejador);
        menuItem7.addActionListener(manejador);
        menuItem8.addActionListener(manejador);
        menuItem9.addActionListener(manejador);
        menuItem10.addActionListener(manejador);
        menuItem11.addActionListener(manejador);
        menuItem12.addActionListener(manejador);        
        menuItem13.addActionListener(manejador);
        menuItem14.addActionListener(manejador);
        menuItem15.addActionListener(manejador);
        
        importBook.addActionListener(manejador);
        deleteBook.addActionListener(manejador);
        listBook.addActionListener(manejador);
        
        searchBook.addActionListener(manejador);
     //   searchField.addActionListener(new textListener());
        
        comboBox.addActionListener(manejador);
  
    }
    
    private class textListener implements DocumentListener
    {
        public void insertUpdate(DocumentEvent ev) {
    }
    
    public void removeUpdate(DocumentEvent ev) {
    }
    
    public void changedUpdate(DocumentEvent ev) {
    }
    
/*    class CancelAction extends AbstractAction {
        public void actionPerformed(ActionEvent ev) {
        }
    }*/
    }
    
      private class ActionEventHandler implements ActionListener
	{
                @Override
		public void actionPerformed( ActionEvent evento)
		{
		
			if (evento.getSource() == menuItem)
				System.exit(0);
                        
                        if (evento.getSource() == menuItem1)
                        {
                                Font font = new Font("Arial", Font.BOLD, 12);
                                readerArea.setFont(font);
                        }
                        
                        if (evento.getSource() == menuItem2)
                        {
                                Font font = new Font("Verdana", Font.ITALIC, 12);
                                readerArea.setFont(font);
                        }
                         
                        if (evento.getSource() == menuItem3)
                        {
                                readerArea.setForeground(Color.BLACK);
                        }
                        
                        if (evento.getSource() == menuItem4)
                        {
                                readerArea.setForeground(Color.BLUE);
                        }
                        
                        if (evento.getSource() == menuItem5)
                        {
                                readerArea.setForeground(Color.WHITE);
                        }
                        
                        if (evento.getSource() == menuItem6)
                        {
                                readerArea.setForeground(Color.RED);
                        }
                        
                        if (evento.getSource() == menuItem7)
                        {                               
				readerArea.setBackground(Color.BLACK);
                        }
                        
                        if (evento.getSource() == menuItem8)
                        {                               
				readerArea.setBackground(Color.BLUE);
                        }
                        
                        if (evento.getSource() == menuItem9)
                        {                               
				readerArea.setBackground(Color.WHITE);
                        }
                        
                        if (evento.getSource() == menuItem10)
                        {                               
				readerArea.setBackground(Color.RED);
                        } 
                        
                        if (evento.getSource() == menuItem11)
                        {
                            try{
				Desktop.getDesktop().browse(new URI("http://dictionary.reference.com/browse/"));
                            }
                            catch (URISyntaxException | IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        
                        if (evento.getSource() == menuItem12)
                        {
                            try{
				Desktop.getDesktop().browse(new URI(library.getBook(currentBook).getWebsite()));
                            }
                            catch(IOException | URISyntaxException e)
                            {
                                e.printStackTrace();
                            }
                        }        
                        
                        if (evento.getSource() == menuItem13)
                        {
                            library.sortBy("title");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }    
                        
                        if (evento.getSource() == menuItem14)
                        {
                            library.sortBy("author");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }            
                        
                        if (evento.getSource() == menuItem15)
                        {
                            library.sortBy("genre");
                            
                            titles.removeAll(titles);
                            
                            for(int i=0; i<library.getSize(); i++)
                            {
                                titles.add(library.getBook(i).getTitle());
                            }
                            model.removeAllElements();
                            
                            for(int i=0; i<titles.size(); i++)
                            {
                                model.addElement(titles.get(i));
                            }
                        }  
                        
                        if (evento.getSource() == importBook)
                        {                  
                            File dd = new File("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files2");
                            library.read(dd.listFiles()[0]);
                            System.out.println("******************");
                            System.out.println("******************");
                            titles.add(library.getBook(library.getSize()-1).getTitle());
                            library.display();
                            
                            
                            
                            
                            
                            
                            
                model.addElement(titles.get(titles.size()-1));

                            
                            
                            
                            
                        }
                        
                        if (evento.getSource() == deleteBook)
                        {     
                            //***********************************8
                            //*************************************8
                            //CAN DO THIS WITH THE CLASS VARIABLE titles NOW
                            //*************************************
                            //****************************************
                            boolean success = false;
                            System.out.println("Delete Book Options");
//                            String[] possibleValues = new String[library.getSize()];
//                            for(int i=0; i<library.getSize(); i++)
//                            {
//                                possibleValues[i] = library.getBook(i).getTitle();
//                            }
//
//                            Object selectedValue = JOptionPane.showInputDialog(null,
//                                    "Choose one", "Input",
//                                    JOptionPane.INFORMATION_MESSAGE, null,
//                                    possibleValues, possibleValues[0]);
                            
                                    Object selectedValue = JOptionPane.showInputDialog(null,
                                    "Choose one", "Input",
                                    JOptionPane.INFORMATION_MESSAGE, null,
                                    titles.toArray(), titles.get(0));
                            
                            
/*                            for (int i = 0; i<possibleValues.length; i++)
                            {
                                if(possibleValues[i].equals(selectedValue))
                                {
                                    setReaderText(library.getBook(i).getText());
                                }
                            }
                            
*/
                            titles.remove(selectedValue.toString());
                            success = library.removeBook(selectedValue.toString());
                            System.out.println("Delete Completed?" + success);
                            library.display();
                            
                            
                            
                            
                            
                            
                            
                            model.removeElement(selectedValue);
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        
                        if (evento.getSource() == listBook)
                        {                      
                            System.out.println("It's getting here");
                            String[] possibleValues = new String[library.getSize()];
                            String disp = "";
                            for(int i=0; i<library.getSize(); i++)
                            {
                                //This part may or may not be necessary, but it wasn't working without it, so :-p
                                possibleValues[i] = library.getBook(i).getTitle();
                                disp = disp.concat(possibleValues[i] + "\n");
                            }

                            
                            setReaderText(disp);
//                            String[] possibleValues = { "First", "Second", "Third" };
                            
                            //I'M REALLY NOT SURE WHY IT ISN'T WORKING WITHOUT THIS STUFF.
                            //SOME TYPE OF UPDATE NEEDED PROBABLY
                            //MAKE A NEW LISTENER FOR THESE???
                            return;
                            Object selectedValue = JOptionPane.showInputDialog(null,
                                    "Choose one", "Input",
                                    JOptionPane.INFORMATION_MESSAGE, null,
                                    possibleValues, possibleValues[0]);
                            for (int i = 0; i<possibleValues.length; i++)
                            {
                                if(possibleValues[i].equals(selectedValue))
                                {
                                    setReaderText(library.getBook(i).getText());
                                }
                            }
                            System.out.println(selectedValue.toString());
                            System.out.println(selectedValue.equals("Second"));
                            return;
                            //setReaderText("Book 2\nHIIIIIII\nHOWWWWW\nAREEEEEEEEEE YOUUUUUUUUUUUU");                             
                            System.out.println("It's getting here");                                
                               /* for(int i=0; i<library.getSize(); i++)
                                {
                                    disp = disp + library.getBook(i).getTitle() + "\n";
                                }
                                */

                        }
                        
                        if ( evento.getSource() == searchBook)
                        {
                            String query;
                            query = searchField.getText();
                            System.out.println(library.getBook(currentBook).search(query).get(0).toString());
                            
                            //change this to be more like the SearchExample
                            
                            
                        }
                        
                        /*
                        if (evento.getSource() == comboBox)
                        {                               
                               
                                JOptionPane.showInputDialog("hi");
                        }*/
                        
                        if(comboBox.getSelectedItem() == "Lorem Ipsum")
                        {
                            setReaderText( "\n\t\t LORE IPSUM \n\n"
               + "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id mattis orci. \n"
               + "Suspendisse cursus diam quis arcu fermentum dapibus. Donec lacinia, eros eget \n"
               + "tincidunt varius, sem enim rhoncus tellus, a tempor magna magna et tortor. Integer \n"
               + "mattis augue metus. Proin nec orci fringilla, molestie nibh rhoncus, scelerisque neque. \n"
               + "Nunc mi lorem, ultricies sed mattis vitae, pulvinar euismod magna. Phasellus blandit \n"
               + "diam mauris, eget ornare risus pharetra vel. Vestibulum velit nulla, varius sit amet \n"
               + "felis vel, adipiscing dignissim nisi. Class aptent taciti sociosqu ad litora torquent \n"
               + "per conubia nostra, per inceptos himenaeos. Vestibulum non magna quis nunc hendrerit \n"
               + "scelerisque id vitae dolor.\n" +
               "\n" +
               "Donec justo ipsum, aliquet ac cursus at, consequat a mauris. In consequat vestibulum \n"
               + "laoreet. Donec dictum mollis laoreet. Duis vel feugiat eros, at dapibus dui. Class \n"
               + "aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. \n"
               + "Curabitur lacus magna, lobortis eu arcu vel, interdum commodo arcu. Pellentesque \n"
               + "ultrices pellentesque pellentesque. Proin eget malesuada velit. Proin rhoncus ante in \n"
               + "egestas viverra. Integer gravida a elit vitae viverra. Maecenas tristique nec lacus at \n"
               + "imperdiet. Integer nec est sit amet massa placerat cursus in eget neque. Maecenas \n"
               + "pulvinar elit libero, nec blandit enim posuere in. Fusce aliquam nulla sed velit \n"
               + "accumsan, id eleifend tellus viverra. Aenean vestibulum urna ut tempor pulvinar. In \n"
               + "eleifend pretium nunc, quis dapibus libero aliquet ac.\n" +
               "\n" +
               "Nulla nec arcu et enim ultrices congue in at ligula. Sed bibendum, nisl non aliquam \n"
               + "rutrum, urna sem faucibus dui, sed elementum nisi magna ultrices diam. Ut elit dolor, \n"
               + "hendrerit varius metus et, semper sodales dui. Morbi ultrices enim id libero porttitor, \n"
               + "sit amet auctor augue ornare. Cras placerat mollis sem id adipiscing. In dapibus eros \n"
               + "dolor. Integer eu risus urna. Suspendisse sed eleifend justo. Integer scelerisque et \n"
               + "arcu id porttitor. Maecenas ut ultrices purus, pulvinar hendrerit dui. Vivamus varius \n"
               + "enim id tincidunt interdum. Mauris congue tristique velit, sit amet sodales mi. Integer \n"
               + "tempus semper dui eu sodales. Cras feugiat eget purus nec viverra. Proin feugiat diam \n"
               + "nec blandit aliquet.\n" +
               "\n" +
               "In porta non quam et vehicula. Etiam leo dui, pretium at dictum ut, cursus vel felis. \n"
               + "Vivamus blandit posuere eros. Etiam ornare purus sit amet luctus porttitor. Nam \n"
               + "porttitor diam est, eget accumsan enim volutpat vel. Nullam tincidunt euismod dignissim. \n"
               + "Donec sagittis nisi ac orci gravida tempus. Praesent ac nisi a odio ultricies consectetur. Duis non interdum erat.\n" +
               "\n" +
               "Phasellus ullamcorper nibh libero, et molestie augue consectetur sed. Maecenas velit leo, \n"
               + "rhoncus et dapibus sit amet, mollis sit amet sem. Fusce adipiscing dictum pellentesque. \n"
               + "Duis iaculis felis vel sem volutpat, in mattis leo rhoncus. Vivamus sollicitudin \n"
               + "volutpat purus, ac pulvinar dolor. Suspendisse fringilla leo ac tincidunt lacinia. \n"
               + "Nulla vel urna in lacus tristique mattis. Aliquam eget molestie magna, in pharetra arcu. \n"
               + "Maecenas aliquam turpis at viverra tempus. Cras laoreet, quam eu rutrum auctor, felis \n"
               + "nunc congue eros, eu ultrices lorem lacus a nulla. Vestibulum luctus mi placerat neque \n"
               + "commodo luctus. Fusce at nisi tristique, blandit tortor eu, imperdiet lectus. Cras sed \n"
               + "commodo nisi. In hac habitasse platea dictumst.\n");
          
                        }
                        
                        if(comboBox.getSelectedItem() == "Book 2")
                        {
                               //JOptionPane.showInputDialog("Book 2");
                            setReaderText("Book 2\nHIIIIIII\nHOWWWWW\nAREEEEEEEEEE YOUUUUUUUUUUUU");
                        }
                        
                        if(comboBox.getSelectedItem() == "Book 3")
                        {
                             setReaderText("Book 3 THIS IS A DIFFERENT STORY\n I HOPE YOU ARE DOING GREAT");
                        }
                        
                        for(int i = 0; i<titles.size(); i++)
                        {
                            if(comboBox.getSelectedItem() == titles.get(i))
                            {
                                setReaderText(library.getBook(i).getText());
                                currentBook = titles.get(i);
                            }
                        }
                        
                }
        }
      
      
      public void setReaderText()
      {
          String text1;
        
          text1 = "\n\t\t LORE IPSUM \n\n"
               + "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id mattis orci. \n"
               + "Suspendisse cursus diam quis arcu fermentum dapibus. Donec lacinia, eros eget \n"
               + "tincidunt varius, sem enim rhoncus tellus, a tempor magna magna et tortor. Integer \n"
               + "mattis augue metus. Proin nec orci fringilla, molestie nibh rhoncus, scelerisque neque. \n"
               + "Nunc mi lorem, ultricies sed mattis vitae, pulvinar euismod magna. Phasellus blandit \n"
               + "diam mauris, eget ornare risus pharetra vel. Vestibulum velit nulla, varius sit amet \n"
               + "felis vel, adipiscing dignissim nisi. Class aptent taciti sociosqu ad litora torquent \n"
               + "per conubia nostra, per inceptos himenaeos. Vestibulum non magna quis nunc hendrerit \n"
               + "scelerisque id vitae dolor.\n" +
               "\n" +
               "Donec justo ipsum, aliquet ac cursus at, consequat a mauris. In consequat vestibulum \n"
               + "laoreet. Donec dictum mollis laoreet. Duis vel feugiat eros, at dapibus dui. Class \n"
               + "aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. \n"
               + "Curabitur lacus magna, lobortis eu arcu vel, interdum commodo arcu. Pellentesque \n"
               + "ultrices pellentesque pellentesque. Proin eget malesuada velit. Proin rhoncus ante in \n"
               + "egestas viverra. Integer gravida a elit vitae viverra. Maecenas tristique nec lacus at \n"
               + "imperdiet. Integer nec est sit amet massa placerat cursus in eget neque. Maecenas \n"
               + "pulvinar elit libero, nec blandit enim posuere in. Fusce aliquam nulla sed velit \n"
               + "accumsan, id eleifend tellus viverra. Aenean vestibulum urna ut tempor pulvinar. In \n"
               + "eleifend pretium nunc, quis dapibus libero aliquet ac.\n" +
               "\n" +
               "Nulla nec arcu et enim ultrices congue in at ligula. Sed bibendum, nisl non aliquam \n"
               + "rutrum, urna sem faucibus dui, sed elementum nisi magna ultrices diam. Ut elit dolor, \n"
               + "hendrerit varius metus et, semper sodales dui. Morbi ultrices enim id libero porttitor, \n"
               + "sit amet auctor augue ornare. Cras placerat mollis sem id adipiscing. In dapibus eros \n"
               + "dolor. Integer eu risus urna. Suspendisse sed eleifend justo. Integer scelerisque et \n"
               + "arcu id porttitor. Maecenas ut ultrices purus, pulvinar hendrerit dui. Vivamus varius \n"
               + "enim id tincidunt interdum. Mauris congue tristique velit, sit amet sodales mi. Integer \n"
               + "tempus semper dui eu sodales. Cras feugiat eget purus nec viverra. Proin feugiat diam \n"
               + "nec blandit aliquet.\n" +
               "\n" +
               "In porta non quam et vehicula. Etiam leo dui, pretium at dictum ut, cursus vel felis. \n"
               + "Vivamus blandit posuere eros. Etiam ornare purus sit amet luctus porttitor. Nam \n"
               + "porttitor diam est, eget accumsan enim volutpat vel. Nullam tincidunt euismod dignissim. \n"
               + "Donec sagittis nisi ac orci gravida tempus. Praesent ac nisi a odio ultricies consectetur. Duis non interdum erat.\n" +
               "\n" +
               "Phasellus ullamcorper nibh libero, et molestie augue consectetur sed. Maecenas velit leo, \n"
               + "rhoncus et dapibus sit amet, mollis sit amet sem. Fusce adipiscing dictum pellentesque. \n"
               + "Duis iaculis felis vel sem volutpat, in mattis leo rhoncus. Vivamus sollicitudin \n"
               + "volutpat purus, ac pulvinar dolor. Suspendisse fringilla leo ac tincidunt lacinia. \n"
               + "Nulla vel urna in lacus tristique mattis. Aliquam eget molestie magna, in pharetra arcu. \n"
               + "Maecenas aliquam turpis at viverra tempus. Cras laoreet, quam eu rutrum auctor, felis \n"
               + "nunc congue eros, eu ultrices lorem lacus a nulla. Vestibulum luctus mi placerat neque \n"
               + "commodo luctus. Fusce at nisi tristique, blandit tortor eu, imperdiet lectus. Cras sed \n"
               + "commodo nisi. In hac habitasse platea dictumst.\n";
          
          readerArea.setBackground(Color.WHITE);
          readerArea.setForeground(Color.BLACK);
          
          readerArea.setText(text1);
      }
      
      public void setReaderText(String text)
      {   
          readerArea.setText(text);
      }
}
