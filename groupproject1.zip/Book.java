/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author Andrew
 */
public class Book {
    
    //do these by chapter?
    private ArrayList<String> text;
    private String title, author, genre, website, iconReference, textAddress, stringText;
    File filename;
    private int attributes, chapters;
    
    
    public Book(String t, String a, String g, String w, String i, String ta, int c)
    {
        title = t;
        author = a;
        genre = g;
        website = w;
        iconReference = i;
        textAddress = ta;
        stringText = "Not initialized";
        filename = new File("textAddress");
        chapters = c;
        text = new ArrayList<>();
        
    }
    
    public Book()
    {
        text = new ArrayList<>();
        stringText = "Not initialized";
    }
    
    public void updateAll(String[] t)
    {
        title = t[0];
        author = t[1];
        genre = t[2];
        website = t[3];
        iconReference = t[4];
        textAddress = t[5];
        chapters = new Integer(t[6]);
    }
    
    public void addText(String t)
    {
        text.add(t);
    }
    
    public String getText()
    {
        stringText = "";
        for(int i=0; i<text.size(); i++)
        {
            stringText = stringText + text.get(i)+" \n";
        }
        return stringText;
    }

    public int getNumChapters()
    {
        return chapters;
    }
    
    public int getAttributes()
    {
        return attributes;
    }

    public String getTitle()
    {
        return title;
    }
    
    public String getAuthor()
    {
        return author;
    }
    
    public String getGenre()
    {
        return genre;
    }
    
    public String getWebsite()
    {
        return website;
    }
    
    public String getIconReference()
    {
        return iconReference;
    }
    
    public String getTextAddress()
    {
        return textAddress;
    }    
        
    public void setAttributes(int a)
    {
        attributes = a;
    }
    
    public void setTitle(String t)
    {
        title = t;
    }
    
    public void setAuthor(String a)
    {
        author = a;
    }
    
    public void setGenre(String g)
    {
        genre = g;
    }
    
    public void setWebsite(String w)
    {
        website = w;
    }
    
    public void setIconReference(String i)
    {
         iconReference = i;
    }
    
    public void setTextAddress(String ta)
    {
        textAddress = ta;
    }
    
    //This would print the entire text file using an attached printer
    public void print()
    {
        
    }
    
    //This would save the current version of the text so that changes are preserved
    public void save()
    {
  /*      System.out.println(textAddress+"\\"+title + ".txt");
        File f = new File(textAddress+"\\"+title + ".txt");
        System.out.println(f.toString());
        f.renameTo(new File(textAddress + "\\NEW\\" + title + ".ubr"));
        System.out.println(f.toString());
       
      try{
     Path source;
     source = Paths.get("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files");      
     Path newdir;
     newdir = Paths.get("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files\\tmp");  
//     Path newdir = textAddress + "\\NEW\\" ;
     Files.move(source, newdir);
//     Files.move(source, newdir.resolve(source.getFileName()));     
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }*/
    }
    
    //This would return the text for viewing
    public void open()
    {
        
    }
    
    //Returns an ArrayList of String with the chapter, then starting index of matching strings
    public ArrayList<String> search(String searchString)
    {
        //use indexOf() on String methods
        ArrayList<String> results = new ArrayList<>();
        int index = -2;
        int start = 0;
        
        for(int i=0; i<text.size(); i++)
        {
            while(index!=-1)
            {
                index = text.get(i).indexOf(searchString , 0);
                if(index > -1)
                {
                    results.add(i + "." + index);
                    index = -2;
                }
            }
            
        }
        
        
        return results;   
    }
    
    //This requires access to the internet
    public void dictionary(String word)
    {
        try
        {
            Desktop.getDesktop().browse(new URI("http://dictionary.reference.com/browse/" + word));
        }
        catch (URISyntaxException | IOException e)
        {
            e.printStackTrace();
        }

        
    }
    
    public String getHighlighted()
    {
        search("<");
        return it all;
    }
    
    public String getChapter(int num)
    {
        return text.get(num-1);
    }
    
    
}
