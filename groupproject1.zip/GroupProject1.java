/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Andrew
 */
public class GroupProject1 {

    /**
     * @param args the command line arguments
     */
 //   public static void main(String[] args) {
        initialize();
        // TODO code application logic here
//        Book b = new Book();
//        b.dictionary("Hello");
        
/*        //make the library static
        Library l = new Library();
        l.initialize();
        l.display();        
        l.getBook("A Totally Legit Book").save();
        System.out.println(" COMPLETE ");
        
        
       // System.out.println(l.getChapter("B Totally Legit Book", 2));
        System.out.println(l.getAChapter(2,2));
        System.out.println(l.getBook("A Totally Legit Book").getTitle());
//        System.out.println(" ");
        //String a = l.getChapter("A Totally Legit Book", 1);
        System.out.println(l.getAChapter(1,4));
       // System.out.println(a);
       */ 

    }
       public static void initialize()
    {
        File parent = new File("C:\\Users\\Andrew\\Documents\\utb\\Software Engineering\\Projects\\Group Project\\Group Project Input Files");
        //You can check that the File is a directory with...
        
        if (parent.isDirectory()) {
    // Take action of the directory
            }

        //You can list the contents of the directory by...

 //       File[] children = parent.listFiles();
        // This will return null if the path does not exist it is not a directory...
        //You can filter the list in a similar way...
        
        //I changed this from ".ubr"  
        //I may need to change it back later.
        File[] children = parent.listFiles(new FileFilter() {
            public boolean accept(File file) {
                return file.isDirectory() || file.getName().toLowerCase().endsWith(".txt");
            }
        });
// This will return all the files that are directories or whose file name ends
// with ".dat" (*.dat)
        
        
        //Then go through one at a time, adding each as a book to the library.
        for(int i=0; i<children.length; i++)
        {
            System.out.println(children[i].toString());
            readWrite(children[i]);
            
            //read children[i] in using a file reader (that needs to be cleaned each time?)
            //Then create a new book with the first 5 lines
            //Then add the new book to the library
        }
    }
       
       
public static void readWrite(File fileName)
    {
        try{
            String absolutePath = fileName.getAbsolutePath();
            System.out.println("File path : " + absolutePath);
            String filePath = absolutePath.substring(0,absolutePath.lastIndexOf(File.separator));
            System.out.println("File path : " + filePath);
            
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(filePath+"\\1"+fileName.getName())));
        String inLine[] = new String[6];
        String line;
        String stringIn = "";
        for(int i = 0; i < 6; i++)
        {
            stringIn = in.readLine();
            out.println(stringIn);
            
        }
        
        
        while((line = in.readLine()) != null)
        {
            out.println(line+"\n");
        }


         

        System.out.println("Book successfully read in");
        in.close();
        out.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
    }


}

